<?php
require("dbfunction.php");
require("dbconnection.php");
require("inputFilter.php");
//execute select statement and diplay event  Seva Manorthi RSVP //
header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST,PUT, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");
$data = json_decode(file_get_contents('php://input'), TRUE);
if(!empty([$data]))
{
  $id= !empty($data['id'])? inputFilter(($data['id'])): null;
  $firstName = !empty($data['firstName'])? inputFilter(($data['firstName'])): null;
  $lastName = !empty($data['lastName'])? inputFilter(($data['lastName'])): null;
   $email = !empty($data['email'])? inputFilter(($data['email'])): null;
   $Message = !empty($data['Message'])? inputFilter(($data['Message'])): null;
   $PhoneNo = !empty($data['PhoneNo'])? inputFilter(($data['PhoneNo'])): null;



echo $id;
$result = $db->prepare("update register SET
firstName='$firstName',
lastName='$lastName',
  email='$email',
    Message='$Message',
       PhoneNo='$PhoneNo'

  WHERE id = '$id' ");

// Execute the query
  if($result->execute())
  {
    echo json_encode(array('result'=>'success'));
    }else{
    echo json_encode(array('result'=>'fail'));
    }
}
?>
