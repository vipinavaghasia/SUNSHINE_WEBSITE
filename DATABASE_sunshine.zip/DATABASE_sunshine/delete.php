<?php

require("dbconnection.php");
//execute select statement and diplay event  Seva Manorthi RSVP //
header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST,DELETE, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");



    $id=$_GET['id'];



$result = $db->prepare("DELETE  from  register WHERE id  = :id ");
$result->bindParam("id", $id, PDO::PARAM_STR);
 $result->execute();





?>
