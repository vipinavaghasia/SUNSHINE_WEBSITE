<?php

require("dbconnection.php");
require("inputFilter.php");
//execute select statement and diplay event  Seva Manorthi RSVP //
header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");
$data = json_decode(file_get_contents('php://input'), TRUE);
if(!empty([$data]))
{



 $name = !empty($data['name'])? inputFilter(($data['name'])): null;

	$email = !empty($data['email'])? inputFilter(($data['email'])): null;
  $subject = !empty($data['subject'])? inputFilter(($data['subject'])): null;
	$message = !empty($data['message'])? inputFilter(($data['message'])): null;
	$phone = !empty($data['phone'])? inputFilter(($data['phone'])): null;
    $sql="INSERT INTO register (name,email,subject,message,phone)
      VALUES(?,?,?,?,?)";
      $stmt= $db->prepare($sql);

       if($stmt->execute([ $name,$email,$subject,$message,$phone]))
       {
    echo json_encode(
      array(
        "success" => "Your message has been sent. Thank you."


      ));

      http_response_code(200);
    }
    else{
      echo json_encode(
        array(
          "success" => " Please try again ."));
    }


    }



?>
