<?php

 require("dbconnection.php");

header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST,update,DELETE, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");


// get id from url

    $id=$_GET['id'];

  $result = $db->prepare("SELECT * from register
    WHERE id  = :id  ");
  $result->bindParam("id", $id, PDO::PARAM_STR);
  $result->execute();


  $q = array();
    $std=$result->fetchAll(PDO::FETCH_ASSOC);
    foreach($std as $row){
      $q[] = $row;
    }
    header('Content-Type:application/json');
    echo json_encode($q);

  
?>
