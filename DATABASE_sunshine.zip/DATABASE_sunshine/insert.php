<?php
require("dbfunction.php");
require("dbconnection.php");
require("inputFilter.php");
//execute select statement and diplay event  Seva Manorthi RSVP //
header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");
$data = json_decode(file_get_contents('php://input'), TRUE);
if(!empty([$data]))
{



 $username = !empty($data['username'])? inputFilter(($data['username'])): null;
 $password = !empty($data['password'])? inputFilter(($data['password'])): null;
  $firstName = !empty($data['firstName'])? inputFilter(($data['firstName'])): null;
  $lastName = !empty($data['lastName'])? inputFilter(($data['lastName'])): null;
   $age = !empty($data['age'])? inputFilter(($data['age'])): null;
    $salary = !empty($data['salary'])? inputFilter(($data['salary'])): null;

register($username,$password,$firstName,$lastName,$age,$salary);
}
?>
