<?php
// Allow from any origin
   if (isset($_SERVER['HTTP_ORIGIN'])) {
       header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
       header('Access-Control-Allow-Credentials: true');
       header('Access-Control-Max-Age: 86400');    // cache for 1 day
   }

   // Access-Control headers are received during OPTIONS requests
   if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

       if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
           header("Access-Control-Allow-Methods: GET, POST,PUT,DELETE, OPTIONS");

       if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
           header("Access-Control-Allow-Headers:        {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

       exit(0);
   }

require("dbconnection.php");
require("inputFilter.php");
require_once('vendor/autoload.php');
use \Firebase\JWT\JWT;



define('SECRET_KEY','Super-Secret-Key');  // secret key can be a random string and keep in secret from anyone
define('ALGORITHM','HS256');   // Algorithm used to sign the token





//Login section

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);


$action = $request->action;



if ($action == 'login') {

	$email = $request->email;
	$password = $request->password;


//$e="nn@gmail.com";
	//$p="nn";

 //$email = !empty($data['email'])? inputFilter(($data['email'])): null;
 //$pwd = !empty($data['password'])? inputFilter(($data['password'])): null;


		  //Retrieve the employee account information for the given email.
		$sql="SELECT * FROM `employee` WHERE `email`=:email";
   $stmt=$db->prepare($sql);
	      //Bind value.
    $stmt->bindValue(':email', $email);


    //Execute.
    $stmt->execute();

    $num = $stmt->rowCount();

 if($num > 0){
   $row = $stmt->fetch(PDO::FETCH_ASSOC);
     $id = $row['Id'];

     $name = $row['name'];
     $email = $row['email'];
	      $pwd1=$row['pwd'];

    if(password_verify($password,$pwd1))
    {

      $iat = time(); // time of token issued at
      $nbf = $iat + 10; //not before in seconds
      $exp = $iat + 60; // expire time of token in seconds

      $token = array(
        "iss" => "http://example.org",
        "aud" => "http://example.com",
        "iat" => $iat,
        "nbf" => $nbf,
        "exp" => $exp,
        "data" => array(
            "id" => $id,
            "email" => $email
        )
      );

      http_response_code(200);

      $jwt = JWT::encode($token, SECRET_KEY);


      $data_insert=array(
        'access_token' => $jwt,
        'id'   => $id,
        'name' => $name,
        'time' => time(),

        'email' => $email,
        'status' => "success",
        'message' => "Successfully Logged In"
      );


    }


    else{
			$data_insert=array(
				"data" => "0",
				"status" => "invalid",
				"message" => "Invalid Request"
			);
		}
}}
// Get Dashboard stuff
else if($action == 'stuff'){

	$authHeader = $_SERVER['HTTP_AUTHORIZATION'];
	$temp_header = explode(" ", $authHeader);
	$jwt = $temp_header[1];

    try {
		JWT::$leeway = 10;
        $decoded = JWT::decode($jwt, SECRET_KEY, array(ALGORITHM));

        // Access is granted. Add code of the operation here
// select all data
require("dbconnection.php");
$query = "SELECT * FROM employee ";
$stmt = $db->prepare($query);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
$json = json_encode($results);



		$data_insert=array(
			"data" => json_decode($json),
			"status" => "success",
			"message" => "Request authorized"
		);

    }catch (Exception $e){

		http_response_code(401);

		$data_insert=array(
			//"data" => $data_from_server,
			"jwt" => $jwt,
			"status" => "error",
			"message" => $e->getMessage()
		);

	}
}




// Get Dashboard stuff
else{

    $id=$_GET['id'];
    echo $id;
	$authHeader = $_SERVER['HTTP_AUTHORIZATION'];
	$temp_header = explode(" ", $authHeader);
	$jwt = $temp_header[1];

    try {
		JWT::$leeway = 10;
        $decoded = JWT::decode($jwt, SECRET_KEY, array(ALGORITHM));

        // Access is granted. Add code of the operation here
// select all data
require("dbconnection.php");
$result = $db->prepare("DELETE  from  employee WHERE Id = :id ");
$result->bindParam("id", $id, PDO::PARAM_STR);
 $result->execute();
$json = json_encode($result);

		$data_insert=array(
			"data" => json_decode($json),
			"status" => "success",
			"message" => "Request authorized"
		);

    }catch (Exception $e){

		http_response_code(401);

		$data_insert=array(
			//"data" => $data_from_server,
			"jwt" => $jwt,
			"status" => "error",
			"message" => $e->getMessage()
		);

	}
}











//insert record for employee
if ($action == 'employee') {
$name = $request->name;
$pwd = $request->pwd;
	$email = $request->email;
	$mobile = $request->mobile;
  $authHeader = $_SERVER['HTTP_AUTHORIZATION'];
	$temp_header = explode(" ", $authHeader);
	$jwt = $temp_header[1];

    try {
		JWT::$leeway = 10;
        $decoded = JWT::decode($jwt, SECRET_KEY, array(ALGORITHM));

        // Access is granted. Add code of the operation here
// add employeed record in database
require("dbconnection.php");
echo "$name\n";
echo "$pwd\n";
 echo" $email \n" ;

   echo "$mobile \n";

$pwd=password_hash($pwd,PASSWORD_DEFAULT);

   $sql="INSERT INTO employee (name,pwd,email,mobile)
     VALUES(?,?,?,?)";





     $stmt= $db->prepare($sql);

      if($stmt->execute([ $name,$pwd,$email,$mobile]))
      {
   echo json_encode(
     $data_insert=array(
       	"status" => "success",
	"message" => "Successfully register"

     ));

     http_response_code(200);
   }
   else{
     echo json_encode(
       $data_insert=array(
         "success" => " Please try again ."));
   }
        }
        catch (Exception $e){

        http_response_code(401);

        $data_insert=array(
          //"data" => $data_from_server,

          "status" => "error",
          "message" => $e->getMessage()
        );

      }
    }





echo json_encode($data_insert);

?>
