<?php
require("dbconnection.php");
require("inputFilter.php");

header("Access-Control-Allow-Origin: http://localhost:4200");
header('Access-Control-Allow-Methods: GET, POST,DELETE, OPTIONS');
header("Access-Control-Allow-Headers: Content-Type, Authorization");



// get id from url

  $id=$_GET['id'];



$result = $db->prepare("DELETE  from register WHERE id  = :id ");
$result->bindParam("id", $id, PDO::PARAM_STR);

if($result->execute())
{
echo json_encode(
array(
 "success" => "Your Contect Successfully delete Thank you."


));

http_response_code(200);
}
else{
echo json_encode(
 array(
   "success" => " Please try again ."));
}

?>
